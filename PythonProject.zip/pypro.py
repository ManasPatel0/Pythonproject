# 1.Import Libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

# 2.Load dataset
df = pd.read_csv('sample_-_superstore.csv')

#3. Summary Statistics
summary_stats = df.describe(include='all')
skewness = df.skew(numeric_only=True)
kurtosis = df.kurtosis(numeric_only=True)
print(" Summary Statistics:")
print(summary_stats)
print("\nSkewness of Numerical Columns:")
print(skewness)
print("\n Kurtosis of Numerical Columns:")
print(kurtosis)

# 4. Summary statistics for numerical and categorical columns
summary_stats = df.describe(include='all')
skewness = df.skew(numeric_only=True)
kurtosis = df.kurtosis(numeric_only=True)
print("Summary Statistics:")
print(summary_stats)
print("\n Skewness of Numerical Columns:")
print(skewness)
print("\n Kurtosis of Numerical Columns:")
print(kurtosis)

#5. Missing Data Visualization
plt.figure(figsize=(10, 4))
sns.heatmap(df.isnull(), cbar=False, cmap="YlGnBu")
plt.title("Missing Data Heatmap")
plt.show()

#6. Sales & Profit by Category

# Total Sales by Category
plt.figure(figsize=(8, 4))
sns.barplot(x='Category', y='Sales', hue='Category', data=df, estimator=np.sum, palette='pastel', legend=False)
plt.title("Total Sales by Category")
plt.ylabel("Total Sales")
plt.show()

# Total Profit by Category
plt.figure(figsize=(8, 4))
sns.barplot(x='Category', y='Profit', hue='Category', data=df, estimator=np.sum, palette='viridis', legend=False)
plt.title("Total Profit by Category")
plt.ylabel("Total Profit")
plt.show()

# 7. Sales vs Profit Scatterplot
# Sales vs Profit scatterplot with category and region as color/style
plt.figure(figsize=(8, 5))
sns.scatterplot(data=df, x='Sales', y='Profit', hue='Category', style='Region', palette='Set1')
plt.title("Sales vs Profit by Category and Region")
plt.show()

# 8. Distribution Analysis
# Sales Distribution
plt.figure(figsize=(8, 4))
sns.histplot(df['Sales'], kde=True, bins=30, color='skyblue')
plt.title('Sales Distribution')
plt.show()

# Profit Distribution
plt.figure(figsize=(8, 4))
sns.histplot(df['Profit'], kde=True, bins=30, color='orange')
plt.title('Profit Distribution')
plt.show()

#9. Correlation Matrix
# Correlation Matrix for numerical features
plt.figure(figsize=(10, 6))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5)
plt.title("Feature Correlation Heatmap")
plt.show()

#10. Profit by Region and Segment
# Profit by Region and Segment
plt.figure(figsize=(8, 4))
sns.barplot(x='Region', y='Profit', hue='Segment', data=df, estimator=np.sum, palette='Accent')
plt.title("Profit by Region and Segment")
plt.show()

#11. Top 10 Sub-Categories by Total Sales
top_sub = df.groupby('Sub-Category')['Sales'].sum().sort_values(ascending=False).head(10)
plt.figure(figsize=(10, 4))
sns.barplot(x=top_sub.index, y=top_sub.values, hue=top_sub.index, palette='Set3', legend=False)
plt.title("Top 10 Sub-Categories by Sales")
plt.ylabel("Total Sales")
plt.show()

#12. Pie Chart: Ship Mode
# Ship Mode Distribution
ship_counts = df['Ship Mode'].value_counts()
plt.figure(figsize=(5, 5))
plt.pie(ship_counts, labels=ship_counts.index, autopct='%1.1f%%', colors=sns.color_palette("pastel"))
plt.title('Ship Mode Distribution')
plt.show()

#13. Violin Plot for Profit by Category
plt.figure(figsize=(8, 5))
sns.violinplot(x='Category', y='Profit', hue='Category', data=df, palette='muted', legend=False)
plt.title('Profit Distribution by Category')
plt.show()

#14 .Data Preparation for Modeling
df_model = pd.get_dummies(df.drop(['Order ID', 'Order Date', 'Customer ID', 'Customer Name', 'Product ID', 'Product Name'], axis=1),drop_first=True)

# Output the columns of the final DataFrame ready for modeling
print("\n Data ready for modeling. Columns:")
print(df_model.columns)
